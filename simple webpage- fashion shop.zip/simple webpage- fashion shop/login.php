<html>
<head>
<title>www.Loverscity.com/home</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<style>
#scroll-container {
  
  background-color:f2f8fb;
  border-radius: 5px;
  overflow: hidden;
}
#scroll-text {
  -moz-transform: translateX(100%);
  -webkit-transform: translateX(100%);
  transform: translateX(100%);
  
  -moz-animation: my-animation 15s linear infinite;
  -webkit-animation: my-animation 30s linear infinite;
  animation: my-animation 30s linear infinite;
}
@-moz-keyframes my-animation {
  from { -moz-transform: translateX(100%); }
  to { -moz-transform: translateX(-100%); }
}

@-webkit-keyframes my-animation {
  from { -webkit-transform: translateX(100%); }
  to { -webkit-transform: translateX(-100%); }
}

@keyframes my-animation {
  from {
    -moz-transform: translateX(100%);
    -webkit-transform: translateX(100%);
    transform: translateX(100%);
  }
  to {
    -moz-transform: translateX(-100%);
    -webkit-transform: translateX(-100%);
    transform: translateX(-100%);
  }
  }

.borders{
	        border-style:groove;
            border-color:black;
			border-width:2px;
            padding:10px;
	        background-color:white;
			 opacity: 0.8;
	        margin-top: 10px;
	        text-align:center;
	        border-radius:40px 40px;

            
}
.borders2{
	        border-style:groove;
            border-color:black;
			border-width:2px;
            padding:10px;
	        background-color:white;
			 opacity: 0.65;
	        margin-top: 10px;
	        text-align:center;
	        border-radius:40px 40px;

            
}
.bodytype{
width:500px;
background-position:center;
float: right;
padding-right:100px;


}
.bodytype2{
width:500px;
background-position:center;
float:left;
padding-left:100px;

}
img{

height:75px;
width:75px;
}
.image{
height:100px;
width:100px;
}
body{
background-image:url("background.jpg");
height:600px;

}
</style>
<body>
<div id="scroll-container">
  <div id="scroll-text"><h5><font color="blue">www.loverscity.com</font>  - <font color="red">join with us </font></h5>
</div>
</div><br>
<div class="bodytype2">
<div class="borders2">
<br><br><center><img src="signin.png"></center>

<p><h1><b><font color="blue">User account</font></b></h1></p>

<form action="insert.php" method="post">
<p>
      <label for="firstName">First Name:</label>
      <input type="text" name="first_name" id="firstName">
      </p>

      
<p>
      <label for="lastName">Last Name:</label>
      <input type="text" name="last_name" id="lastName">
      </p>

      
<p>
      <label for="Gender">Gender:</label>
      <input type="text" name="gender" id="Gender">
      </p>

      
<p>
      <label for="Address">Address:</label>
      <input type="text" name="address" id="Address">
      </p>

      
<p>
      <label for="emailAddress">Email Address:</label>
      <input type="text" name="email" id="emailAddress">
      </p>

      <input type="submit" value="submit">
      
</form>

</div>
</div>
<div class="bodytype">
<div class="borders">
<br><br><left-align><img src="logo user.png"></left-align><br>
	
<br><h1><p><b><font color="blue">sign in</font></b></h1></p>
<form action=""method="">
<h3>User name :</h3><input type="text"name="name"placeholder="enter emaill address"><br><br>
<h3>Password  :</h3><input type="password"name="pwd"placeholder="enter password"><br>
<input type="checkbox" class="form-check-input" id="exampleCheck1"> Remember me<br><br>
<a href="#" class="btn btn-primary">Signin</a>
<a href="#" class="btn btn-secondary">Reset</a>
</form>
</div>
</div>


</body>
</html>